import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

function Upload() {
  const [files, setFiles] = useState([]);
  const [statusMessages, setStatusMessages] = useState([]);
  const { userEmail } = useAuth(); // need for sns

  const API_GATEWAY_URL = 'https://rg9x908q8h.execute-api.us-east-1.amazonaws.com/prod/FileSegregation';

  const handleDrop = (event) => {
    event.preventDefault();
    const droppedFiles = Array.from(event.dataTransfer.files);
    setFiles((prev) => [...prev, ...droppedFiles]);
  };

  const handleFileChange = (event) => {
    const selectedFiles = Array.from(event.target.files);
    setFiles((prev) => [...prev, ...selectedFiles]);
  };

  const handleUpload = async () => {
    const messages = [];

    for (const file of files) {
      try {
        const token = sessionStorage.getItem('accessToken');

        const res = await fetch(API_GATEWAY_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            file_name: file.name,
            content_type: file.type,
            file_size: file.size,
          }),
        });

        if (!res.ok) {
          messages.push(`❌ ${file.name} failed to get upload URL`);
          continue;
        }

        const { presigned_url } = await res.json();

        const uploadRes = await fetch(presigned_url, {
          method: 'PUT',
          headers: { 'Content-Type': file.type },
          body: file,
        });

        if (uploadRes.ok) {
          messages.push(`✅ ${file.name} uploaded successfully`);
        } else {
          messages.push(`❌ ${file.name} upload failed`);
        }
      } catch (err) {
        messages.push(`❌ ${file.name} error: ${err.message}`);
      }
    }

    setStatusMessages(messages);
    setFiles([]);
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 px-6 py-12">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-6 text-blue-600">📤 Upload Files</h1>

        <div
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          className="border-2 border-dashed border-gray-300 bg-blue-50 p-10 rounded-xl text-center shadow-sm hover:shadow-md transition-all"
        >
          <p className="text-base font-medium text-gray-800 mb-1">Click to upload or drag files here</p>
          <p className="text-sm text-gray-600">
            Supported: Images (JPG, PNG) | Audio (MP3, WAV) | Video (MP4, AVI)
          </p>
          <label className="cursor-pointer inline-block mt-4 text-blue-600 hover:underline">
            <span>Select Files</span>
            <input
              type="file"
              multiple
              onChange={handleFileChange}
              className="hidden"
            />
          </label>
        </div>

        {files.length > 0 && (
          <div className="mt-6 bg-white p-4 rounded shadow-sm">
            <h3 className="text-md font-semibold mb-2 text-gray-800">📂 Selected Files:</h3>
            <ul className="list-disc list-inside text-sm text-gray-700">
              {files.map((file, idx) => (
                <li key={idx}>{file.name}</li>
              ))}
            </ul>
          </div>
        )}

        <button
          onClick={handleUpload}
          className="mt-6 w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-md shadow-sm"
        >
          Upload All
        </button>

        {statusMessages.length > 0 && (
          <div className="mt-6 bg-white p-4 rounded shadow-sm text-sm text-left">
            <h4 className="text-blue-600 font-semibold mb-2">Upload Status:</h4>
            <ul className="list-disc list-inside text-green-600">
              {statusMessages.map((msg, idx) => (
                <li key={idx}>{msg}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}

export default Upload;