import React, { useState } from 'react';
import { signUp, loginUser, confirmUser } from '../utils/cognito';
import { useAuth } from '../contexts/AuthContext';

function Login() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmationCode, setConfirmationCode] = useState('');
  const [status, setStatus] = useState('');
  const [mode, setMode] = useState('signup'); // signup | confirm | login

  const { login } = useAuth();

  const handleSignup = async () => {
    setStatus('Signing up...');
    try {
      await signUp(email, password, name);
      setStatus('✅ Signup successful! Check email for confirmation code.');
      setMode('confirm');
    } catch (err) {
      setStatus(`❌ Signup failed: ${err.message}`);
    }
  };

  const handleConfirm = async () => {
    setStatus('Confirming...');
    try {
      await confirmUser(email, confirmationCode);
      setStatus('✅ Email confirmed! You can now log in.');
      setMode('login');
    } catch (err) {
      setStatus(`❌ Confirmation failed: ${err.message}`);
    }
  };

  const handleLogin = async () => {
    setStatus('Logging in...');
    try {
      const { accessToken, email: userEmail } = await loginUser(email, password);
      login(userEmail, accessToken);
      setStatus('✅ Logged in!');
      setTimeout(() => {
        window.location.href = '/';
      }, 1000);
    } catch (err) {
      setStatus(`❌ Login failed: ${err.message}`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 px-4 py-12">
      <div className="max-w-md mx-auto bg-white p-8 rounded-xl shadow-md space-y-6 border border-gray-200">
        <h1 className="text-3xl font-bold text-center text-blue-600">🔐 Login / Sign Up</h1>
        <p className="text-center text-gray-500">Access your BirdTag dashboard</p>

        {mode === 'signup' && (
          <>
            <input
              type="text"
              placeholder="Name"
              className="w-full p-3 rounded-md bg-gray-100"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <input
              type="email"
              placeholder="Email"
              className="w-full p-3 rounded-md bg-gray-100"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <input
              type="password"
              placeholder="Password"
              className="w-full p-3 rounded-md bg-gray-100"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              onClick={handleSignup}
              className="w-full bg-black text-white py-2 rounded-md"
            >
              Sign Up
            </button>
            <p className="text-sm text-center text-gray-500">
              Already signed up? <span onClick={() => setMode('login')} className="text-blue-500 cursor-pointer">Log In</span>
            </p>
          </>
        )}

        {mode === 'confirm' && (
          <>
            <input
              type="text"
              placeholder="Enter confirmation code"
              className="w-full p-3 rounded-md bg-gray-100"
              value={confirmationCode}
              onChange={(e) => setConfirmationCode(e.target.value)}
            />
            <button
              onClick={handleConfirm}
              className="w-full bg-green-600 text-white py-2 rounded-md"
            >
              Confirm
            </button>
          </>
        )}

        {mode === 'login' && (
          <>
            <input
              type="email"
              placeholder="Email"
              className="w-full p-3 rounded-md bg-gray-100"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <input
              type="password"
              placeholder="Password"
              className="w-full p-3 rounded-md bg-gray-100"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              onClick={handleLogin}
              className="w-full bg-blue-600 text-white py-2 rounded-md"
            >
              Log In
            </button>
            <p className="text-sm text-center text-gray-500">
              Don't have an account? <span onClick={() => setMode('signup')} className="text-blue-500 cursor-pointer">Sign Up</span>
            </p>
          </>
        )}

        {status && (
          <div className="text-sm text-center text-green-600">{status}</div>
        )}
      </div>
    </div>
  );
}

export default Login;