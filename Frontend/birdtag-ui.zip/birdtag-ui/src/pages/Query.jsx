import React, { useState } from 'react';
import { API_CONFIG } from '../config';
import { useAuth } from '../contexts/AuthContext';

const birdOptions = ['Crow', 'Peacock', 'Pigeon', 'Myna', 'Owl', 'Kingfisher', 'Sparrow'];

function Query() {
  const { userEmail } = useAuth();
  const token = sessionStorage.getItem('accessToken');

  const [queryType, setQueryType] = useState('tag-count');
  const [tagInputs, setTagInputs] = useState([{ tag: '', count: 1 }]);
  const [simpleTags, setSimpleTags] = useState([]);
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [fileQueryFile, setFileQueryFile] = useState(null);
  const [tagOperation, setTagOperation] = useState(1);
  const [tagEditUrls, setTagEditUrls] = useState('');
  const [tagEditList, setTagEditList] = useState('');
  const [deleteUrls, setDeleteUrls] = useState('');
  const [results, setResults] = useState([]);
  const [statusMessage, setStatusMessage] = useState('');

  const handleInputChange = (index, field, value) => {
    const newInputs = [...tagInputs];
    newInputs[index][field] = value;
    setTagInputs(newInputs);
  };

  const addTagInput = () => {
    setTagInputs([...tagInputs, { tag: '', count: 1 }]);
  };

  const handleQuery = async () => {
    const payload = {};
    tagInputs.forEach(({ tag, count }) => {
      if (tag) payload[tag.toLowerCase()] = parseInt(count); // MATCHING THE EXAMPLE input: {"crow": 2, "pigeon": 1} in Lambda function.. lowercase
    });
    try {
      const res = await fetch(API_CONFIG.QUERY_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      setResults(data.links || []);
    } catch {
      setStatusMessage(' Failed to perform tag+count query.');
    }
  };

  const handleSimpleQuery = async () => {
    const payload = simpleTags.map(bird => bird.toLowerCase());
    try {
      const res = await fetch(API_CONFIG.QUERY_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      setResults(data.links || []);
    } catch {
      setStatusMessage(' Failed to perform species-only query.');
    }
  };

  const handleThumbnailLookup = async () => {
    try {
      const res = await fetch(API_CONFIG.THUMBNAIL_LOOKUP_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ thumbnail_url: thumbnailUrl }),
      });
      const data = await res.json();
      setResults([data.full_image_url]);
    } catch {
      setStatusMessage(' Failed to lookup thumbnail URL.');
    }
  };

  const handleFileQuery = async () => {
    try {
      const formData = new FormData();
      formData.append('file', fileQueryFile);
      const res = await fetch(API_CONFIG.FILE_TAG_QUERY_URL, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });
      const data = await res.json();
      setResults(data.links || []);
    } catch {
      setStatusMessage('❌ Failed to process file query.');
    }
  };

  const handleTagUpdate = async () => {
    const urlList = tagEditUrls.split('\n').map(u => u.trim()).filter(Boolean);
    const tagListRaw = tagEditList.split(',').map(t => t.trim()).filter(Boolean);
  
    // Group into ["crow,1", "sparrow,2"]
    const tagsGrouped = [];
    for (let i = 0; i < tagListRaw.length; i += 2) {
      if (tagListRaw[i + 1]) {
        tagsGrouped.push(`${tagListRaw[i]},${tagListRaw[i + 1]}`);
      }
    }
  
    const payload = {
      url: urlList,
      operation: tagOperation,
      tags: tagsGrouped,
    };
  
    try {
      const res = await fetch(API_CONFIG.TAG_UPDATE_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      setStatusMessage(data.message || 'Tags updated.');
    } catch {
      setStatusMessage(' Failed to update tags.');
    }
  };

  const handleDeleteFiles = async () => {
    const payload = {
      url: deleteUrls.split('\n').map(u => u.trim()).filter(Boolean),
    };
    try {
      const res = await fetch(API_CONFIG.DELETE_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      setStatusMessage(data.message || 'Files deleted.');
    } catch {
      setStatusMessage('❌ Failed to delete files.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white px-4 py-10">
      <div className="max-w-4xl mx-auto space-y-10">

        <div className="text-left">
          <h1 className="text-3xl font-extrabold mb-2">🔍 Search Birds</h1>
          <p className="text-sm text-blue-400 mt-1">Logged in as: <span className="font-semibold">{userEmail}</span></p>
          <p className="text-gray-500 dark:text-gray-400">Search media by tags, uploads or metadata.</p>
        </div>

        {/* Dropdown for query type */}
        <div className="bg-white dark:bg-gray-900 p-6 rounded-xl shadow space-y-4">
          <label className="block font-semibold">Choose a query type:</label>
          <select
            value={queryType}
            onChange={(e) => setQueryType(e.target.value)}
            className="w-full bg-gray-100 dark:bg-gray-800 p-2 rounded"
          >
            <option value="tag-count">Bird Tag + Count</option>
            <option value="species-only">Bird Species Only</option>
            <option value="thumbnail">From Thumbnail URL</option>
            <option value="file-upload"> Upload a File </option>
            <option value="tag-edit">Tag Update</option>
            <option value="delete">Delete Files</option>
          </select>
        </div>

        {queryType === 'tag-count' && (
          <div className="bg-white dark:bg-gray-900 p-6 rounded-xl space-y-4">
            <h2 className="text-lg font-semibold">Bird Tag + Count</h2>
            {tagInputs.map((input, index) => (
              <div key={index} className="flex items-center gap-2">
                <select
                  value={input.tag}
                  onChange={(e) => handleInputChange(index, 'tag', e.target.value)}
                  className="bg-gray-100 dark:bg-gray-800 p-2 rounded"
                >
                  <option value=''>Select bird</option>
                  {birdOptions.map((bird) => (
                    <option key={bird} value={bird}>{bird}</option>
                  ))}
                </select>
                <input
                  type="number"
                  min="1"
                  value={input.count}
                  onChange={(e) => handleInputChange(index, 'count', e.target.value)}
                  className="w-20 p-2 rounded bg-gray-100 dark:bg-gray-800"
                />
                {tagInputs.length > 1 && (
                  <button
                    onClick={() => {
                      const newInputs = [...tagInputs];
                      newInputs.splice(index, 1);
                      setTagInputs(newInputs);
                    }}
                    className="text-red-400 hover:text-red-600"
                  >Remove</button>
                )}
              </div>
            ))}
            <div className="flex gap-3">
              <button onClick={addTagInput} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">Add</button>
              <button onClick={handleQuery} className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">Search</button>
            </div>
          </div>
        )}

        {queryType === 'species-only' && (
          <div className="bg-white dark:bg-gray-900 p-6 rounded-xl space-y-4">
            <h2 className="text-lg font-semibold">Bird Species Only</h2>
            <div className="grid grid-cols-2 gap-2">
              {birdOptions.map((bird) => (
                <label key={bird} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    value={bird}
                    checked={simpleTags.includes(bird)}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      const value = e.target.value;
                      setSimpleTags((prev) =>
                        checked ? [...prev, value] : prev.filter(tag => tag !== value)
                      );
                    }}
                    className="accent-blue-600"
                  />
                  <span>{bird}</span>
                </label>
              ))}
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400">✔️ Select one or more bird species</p>
            <button onClick={handleSimpleQuery} className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">
              Search
            </button>
          </div>
        )}

        {queryType === 'thumbnail' && (
          <div className="bg-white dark:bg-gray-900 p-6 rounded-xl space-y-4">
            <h2 className="text-lg font-semibold">From Thumbnail URL</h2>
            <input
              type="text"
              value={thumbnailUrl}
              onChange={(e) => setThumbnailUrl(e.target.value)}
              placeholder="Enter S3 Thumbnail URL"
              className="w-full p-2 rounded bg-gray-100 dark:bg-gray-800"
            />
            <button onClick={handleThumbnailLookup} className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">Lookup</button>
          </div>
        )}

        {queryType === 'file-upload' && (
          <div className="bg-white dark:bg-gray-900 p-6 rounded-xl space-y-6">
            <h2 className="text-2xl font-bold text-blue-600 mb-4">📄 From Uploaded File</h2>

            <div
              className="border-2 border-dashed border-gray-300 dark:border-gray-700 bg-blue-50 dark:bg-gray-800 p-10 rounded-xl text-center shadow-sm hover:shadow-md transition-all"
            >
              <p className="text-base font-medium text-gray-800 dark:text-gray-200 mb-1">
                Click to upload or drag files here
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Supported: Images (JPG, PNG) | Audio (MP3, WAV) | Video (MP4, AVI)
              </p>

              <label className="cursor-pointer inline-block mt-4 text-blue-600 hover:underline">
                <span>Select File</span>
                <input
                  type="file"
                  onChange={(e) => setFileQueryFile(e.target.files[0])}
                  className="hidden"
                />
              </label>

              {fileQueryFile && (
                <p className="mt-4 text-sm text-gray-700 dark:text-gray-300">
                  Selected: <span className="font-medium">{fileQueryFile.name}</span>
                </p>
              )}
            </div>

            <button
              onClick={handleFileQuery}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-md shadow-sm"
            >
              Submit
            </button>
          </div>
        )}

        {queryType === 'tag-edit' && (
          <div className="bg-white dark:bg-gray-900 p-6 rounded-xl space-y-4">
            <h2 className="text-lg font-semibold">Bulk Tag Update</h2>
            <textarea
              rows={3}
              placeholder="Enter S3 URLs"
              value={tagEditUrls}
              onChange={(e) => setTagEditUrls(e.target.value)}
              className="w-full p-2 rounded bg-gray-100 dark:bg-gray-800"
            />
            <input
              type="text"
              placeholder="Enter tags (e.g. crow, pigeon)"
              value={tagEditList}
              onChange={(e) => setTagEditList(e.target.value)}
              className="w-full p-2 rounded bg-gray-100 dark:bg-gray-800"
            />
            <div className="flex gap-4">
              <label><input type="radio" name="op" checked={tagOperation === 1} onChange={() => setTagOperation(1)} /> Add</label>
              <label><input type="radio" name="op" checked={tagOperation === 0} onChange={() => setTagOperation(0)} /> Remove</label>
            </div>
            <button onClick={handleTagUpdate} className="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded">Submit</button>
          </div>
        )}

        {queryType === 'delete' && (
          <div className="bg-white dark:bg-gray-900 p-6 rounded-xl space-y-4">
            <h2 className="text-lg font-semibold text-red-500">Delete Files</h2>
            <textarea
              rows={4}
              placeholder="Enter S3 URLs to delete"
              value={deleteUrls}
              onChange={(e) => setDeleteUrls(e.target.value)}
              className="w-full p-2 rounded bg-gray-100 dark:bg-gray-800"
            />
            <button onClick={handleDeleteFiles} className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded">Delete</button>
          </div>
        )}

        {statusMessage && (
          <p className="text-center text-green-500 font-medium">{statusMessage}</p>
        )}

        <div className="bg-white dark:bg-gray-900 p-6 rounded-xl shadow space-y-4 border border-gray-300 dark:border-gray-700">
          <h2 className="text-2xl font-semibold">📋 Results</h2>
          {results.length === 0 ? (
            <p className="text-gray-400">No results yet. Perform a search or upload to see results.</p>
          ) : (
            <div className="flex flex-wrap gap-4">
              {results.map((url, i) => (
                <img key={i} src={url} alt="result" className="w-40 h-auto rounded" />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Query;