// src/utils/cognito.js
import {
    CognitoUserPool,
    CognitoUser,
    AuthenticationDetails,
  } from 'amazon-cognito-identity-js';
  
  const poolData = {
    UserPoolId: 'us-east-1_Jp4gXLFvh', // CHANGE IT TO THE USERPOOL ID IN UR AWS ACCT
    ClientId: '6q3189hajdkk08o4sqslmd4716', // CHANGE IT TO THE CLIENT APP ID IN UR AWS ACCT
  };
  
  export const userPool = new CognitoUserPool(poolData);
  
  export function signUp(email, password, name) {
    return new Promise((resolve, reject) => {
      const attributeList = [
        {
          Name: 'email',
          Value: email,
        },
        {
          Name: 'name',
          Value: name,
        },
      ];
  
      userPool.signUp(email, password, attributeList, null, (err, result) => {
        if (err) return reject(err);
        resolve(result.user);
      });
    });
  }
  
  export function confirmUser(email, code) {
    const user = new CognitoUser({ Username: email, Pool: userPool });
    return new Promise((resolve, reject) => {
      user.confirmRegistration(code, true, (err, result) => {
        if (err) return reject(err);
        resolve(result);
      });
    });
  }
  
  export function loginUser(email, password) {
    const authDetails = new AuthenticationDetails({ Username: email, Password: password });
    const user = new CognitoUser({ Username: email, Pool: userPool });
  
    return new Promise((resolve, reject) => {
      user.authenticateUser(authDetails, {
        onSuccess: (result) => {
          const accessToken = result.getAccessToken().getJwtToken();
          resolve({ accessToken, email });
        },
        onFailure: (err) => reject(err),
      });
    });
  }