import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-blue-50 text-gray-800 px-6 py-16">
      <div className="max-w-6xl mx-auto text-center space-y-24">

        {/* Hero */}
        <div>
          <h1 className="text-5xl font-extrabold mb-4 text-blue-700 flex justify-center items-center gap-3">
            🐦 Welcome to BirdTag
          </h1>
          <p className="text-lg text-gray-600 mb-10">
            Effortlessly upload, tag and search bird media with AI-powered precision.
          </p>

          {/* CTA */}
          {isAuthenticated ? (
            <div className="flex flex-col sm:flex-row justify-center gap-6">
              <Link
                to="/upload"
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-semibold shadow-md transition"
              >
                📤 Upload File
              </Link>
              <Link
                to="/query"
                className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-xl font-semibold shadow-md transition"
              >
                🔍 Search Media
              </Link>
            </div>
          ) : (
            <Link
              to="/login"
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-semibold shadow-md transition"
            >
              🚀 Try It Now
            </Link>
          )}
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="bg-white border border-gray-200 p-6 rounded-2xl shadow-sm hover:shadow-md transition">
            <h3 className="text-lg font-bold text-blue-700 mb-2">🕊️ Smart Bird Tagging</h3>
            <p className="text-gray-600 text-sm">
              Upload media and automatically label species using advanced AI models.
            </p>
          </div>
          <div className="bg-white border border-gray-200 p-6 rounded-2xl shadow-sm hover:shadow-md transition">
            <h3 className="text-lg font-bold text-blue-700 mb-2">🔍 Flexible Queries</h3>
            <p className="text-gray-600 text-sm">
              Search by species, tag combinations, thumbnail links or even files.
            </p>
          </div>
          <div className="bg-white border border-gray-200 p-6 rounded-2xl shadow-sm hover:shadow-md transition">
            <h3 className="text-lg font-bold text-blue-700 mb-2">☁️ Secure Cloud Storage</h3>
            <p className="text-gray-600 text-sm">
              All media is stored safely in AWS with optimized access and tagging.
            </p>
          </div>
        </div>

        {/* About Box */}
        <div className="bg-blue-50 border border-blue-100 p-6 rounded-2xl shadow-sm text-left max-w-3xl mx-auto">
          <h2 className="text-xl font-semibold mb-3 text-blue-800">📘 About Monash Birdy Buddies</h2>
          <p className="text-gray-700 text-sm leading-relaxed">
            Monash Birdy Buddies (MBB) is a student-led initiative promoting bird research,
            conservation and tech-powered biodiversity tracking. Our BirdTag platform empowers
            you to contribute to a growing knowledge base of avian life through intelligent tagging
            and discovery.
          </p>
        </div>

        {/* Footer */}
        <p className="text-xs text-gray-400">© 2025 BirdTag · Team 138 · Powered by AWS</p>
      </div>
    </div>
  );
}

export default Home;