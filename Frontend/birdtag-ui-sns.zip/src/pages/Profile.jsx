import React, { useState } from 'react';
import { API_CONFIG } from '../config';
import { useAuth } from '../contexts/AuthContext';

function Profile() {
  const { userEmail } = useAuth();
  const [tagInput, setTagInput] = useState('');
  const [status, setStatus] = useState('');

  const handleSubscribe = async () => {
    const tags = tagInput
      .split(',')
      .map(tag => tag.trim())  // preserves case
      .filter(tag => tag.length > 0);

    if (tags.length === 0) {
      setStatus("Please enter at least one tag.");
      return;
    }

    let allSuccessful = true;

    for (const tag of tags) {
      try {
        const response = await fetch(API_CONFIG.SUBSCRIBE_API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: userEmail, tags: [tag] })  // ✅ important key: `tags` as an array
        });

        if (!response.ok) throw new Error(`Failed to subscribe to ${tag}`);
      } catch (err) {
        console.error(err);
        allSuccessful = false;
      }
    }

    setStatus(
      allSuccessful
        ? `Subscribed successfully to: ${tags.join(', ')}`
        : `Some subscriptions failed.`
    );
  };

  return (
    <div className="max-w-xl mx-auto p-6 bg-white shadow-md rounded-xl mt-6">
      <h1 className="text-2xl font-bold mb-4">Profile</h1>
      <p className="mb-4"><strong>Email:</strong> {userEmail}</p>

      <h2 className="text-lg font-semibold mb-2">Tag Notifications</h2>
      <label className="block mb-2 text-sm font-medium text-gray-700">
        Enter tags (comma-separated):
      </label>
      <input
        type="text"
        value={tagInput}
        onChange={(e) => setTagInput(e.target.value)}
        placeholder="e.g. Crow, Pigeon, Hawk"
        className="w-full px-4 py-2 border border-gray-300 rounded mb-4"
      />

      <button
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        onClick={handleSubscribe}
      >
        Subscribe
      </button>

      {status && <p className="mt-4 text-sm text-green-600">{status}</p>}
    </div>
  );
}

export default Profile;