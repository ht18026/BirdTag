import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

function Navbar() {
  const location = useLocation();
  const { isAuthenticated, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const linkClass = (path) =>
    `px-4 py-2 rounded-md transition-all duration-200 ${
      location.pathname === path
        ? 'bg-blue-600 text-white'
        : 'text-gray-800 dark:text-gray-200 hover:bg-blue-100 dark:hover:bg-gray-800'
    }`;

  return (
    <nav className="bg-white dark:bg-gray-900 shadow-md px-6 py-3 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-blue-600 dark:text-blue-400 hover:opacity-90">
          🐦 BirdTag
        </Link>
        <div className="flex items-center space-x-4 text-sm font-medium">
          <Link to="/" className={linkClass('/')}>Home</Link>

          {isAuthenticated && (
            <>
              <Link to="/upload" className={linkClass('/upload')}>Upload</Link>
              <Link to="/query" className={linkClass('/query')}>Search</Link>
              <Link to="/profile" className={linkClass('/profile')}>Profile</Link> {/* ✅ NEW */}
            </>
          )}

          {isAuthenticated ? (
            <button
              onClick={logout}
              className="ml-2 px-4 py-2 rounded-md bg-red-500 text-white hover:bg-red-600 transition-all"
            >
              Logout
            </button>
          ) : (
            <Link
              to="/login"
              className="ml-2 px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-all"
            >
              Login / Sign Up
            </Link>
          )}

          {/* THEME TOGGLE BUTTON */}
          <button
            onClick={toggleTheme}
            className="ml-2 px-3 py-1 rounded bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white hover:opacity-90"
          >
            {theme === 'dark' ? ' Light' : ' Dark'}
          </button>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;