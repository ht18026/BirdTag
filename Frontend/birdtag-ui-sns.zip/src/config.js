export const API_CONFIG = {
  S3_UPLOAD_URL: "link",
  TAG_COUNT_URL: "https://rg9x908q8h.execute-api.us-east-1.amazonaws.com/prod/tag-query", // TAG+COUNT
  TAG_ONLY_URL: "https://rg9x908q8h.execute-api.us-east-1.amazonaws.com/prod/tag-only", // TAG ONLY
  TAG_UPDATE_URL: "https://rg9x908q8h.execute-api.us-east-1.amazonaws.com/prod/Manuel-update", // UPDATE TAGS (ADD OR DELETE)
  DELETE_API_URL: "https://rg9x908q8h.execute-api.us-east-1.amazonaws.com/prod/deletefilesquery", // DELETE FILES
  THUMB_LOOKUP_URL: "https://rg9x908q8h.execute-api.us-east-1.amazonaws.com/prod/thumbnail-query", // THUMBNAIL LOOKUP
  FILE_TAG_QUERY_URL: "https://rg9x908q8h.execute-api.us-east-1.amazonaws.com/prod/Retrieve-by-fileupload", // FILE UPLOAD SEARCH
  SUBSCRIBE_API_URL: "https://rg9x908q8h.execute-api.us-east-1.amazonaws.com/prod/sns-subscribtion" //SNS LAMBDA
 };
 