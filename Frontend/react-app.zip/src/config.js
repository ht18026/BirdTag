export const API_CONFIG = {
  S3_UPLOAD_URL: "link",
  QUERY_API_URL: "link",
  TAG_API_URL: "link",
  DELETE_API_URL: "link",
  THUMB_LOOKUP_URL: "link",
  FILE_TAG_QUERY_URL: "link"
};